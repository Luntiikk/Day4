﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Лаборатория.DB;

namespace Лаборатория
{
    /// <summary>
    /// Логика взаимодействия для Admin.xaml
    /// </summary>
    public partial class Admin : Window
    {
        private LoginHistory[] historyLogin;
        public Admin()
        {
            InitializeComponent();
            RefreshData();
            cmFilt.ItemsSource = App.medicalLaboratory.
                Users.Select(c => c.login).ToList();
            dgHistory.ItemsSource = App.medicalLaboratory.
                LoginHistories.ToList();
        }

        private LoginHistory[] SortHistory(LoginHistory[] history)//сортировка
        {
            try
            {
                if (cmSort.SelectedIndex == 0)
                    history = history.ToArray();
                if (cmSort.SelectedIndex == 1)
                    history = history.OrderBy(c => c.date).ToArray();//по возрастанию
                if (cmSort.SelectedIndex == 2)
                    history = history.
                        OrderByDescending(c => c.date).ToArray();//по убыванию
            }
            catch { }
            return history;
        }

        private LoginHistory[] FiltHistory(LoginHistory[] history)
        {
            try
            {
                history = history.Where(c => c.User.login.ToLower().
                   Contains(cmFilt.Text.ToLower())).ToArray();
            }
            catch { }
            return history;
        }

        private void RefreshData()//метод для вывода данных 
        {

            historyLogin = App.medicalLaboratory.LoginHistories.ToArray();
            historyLogin = SortHistory(historyLogin);
            historyLogin = FiltHistory(historyLogin);
            dgHistory.ItemsSource = historyLogin.ToList();
        }

        private void cmFilt_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            RefreshData();
        }

        private void cmSort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            RefreshData();
        }

        private void btExit_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
