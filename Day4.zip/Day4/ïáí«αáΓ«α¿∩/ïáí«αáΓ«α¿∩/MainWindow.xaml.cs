﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Лаборатория
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        public class CheckClick : TextBox//Используется для Captcha
        {
            public int error { get; set; }
        }
        int Attempts;
        DateTime now = DateTime.Now;//текущие дата и время  
        int idUser;

        private void enter_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var ForUsers = App.medicalLaboratory.Users.FirstOrDefault
                    (x => x.login == loginUser.Text &&
                    x.password == passwordUser.Password && 
                    x.password == tbUser.Text);//для входа
                int idUsers = App.medicalLaboratory.Users.
                    Where(c=>c.login == loginUser.Text)
                    .Select(c=>c.id).FirstOrDefault();
                if (loginUser == null || passwordUser == null)
                {
                    MessageBox.Show("Заполните данные!");
                }
                else
                {
                    if (ForUsers != null)
                    {

                        switch (ForUsers.type)
                        {
                            case 1://Администратор
                                Admin showAdmin = new Admin();
                                showAdmin.Show();
                                this.Close();
                                break;
                            case 2://Бухгалтер
                                MessageBox.Show("Вы зашли как бухгалтер");
                                break;
                            case 3://Лаборант
                                Laborant laborant = new Laborant();
                                laborant.Show();
                                this.Close();
                                break;
                        }
                        DB.LoginHistory loginHistory = new DB.LoginHistory
                        {
                            idUser = idUsers,
                            date = DateTime.Now,
                            attempt = "Успешно"
                        };
                        App.medicalLaboratory.LoginHistories.Add(loginHistory);
                        App.medicalLaboratory.SaveChanges();
                    }
                    else
                    {
                        Attempts++;
                        UsersFalse();
                        DB.LoginHistory login = new DB.LoginHistory
                        {
                            idUser = idUsers,
                            date = DateTime.Now,
                            attempt = "Неуспешно"
                        };
                        App.medicalLaboratory.LoginHistories.Add(login);
                        App.medicalLaboratory.SaveChanges();

                    }

                }
            }
            catch { }
        }

        System.Windows.Threading.DispatcherTimer
            timer1 = new System.Windows.Threading.DispatcherTimer();
        public void UsersFalse()//Блок неверной капчи
        {
            if (Attempts == 1 || Attempts == 2)
            {
                MessageBoxResult result = MessageBox.Show("Неверно введёт логин или пароль." +
                    "\nПроверьте введённые вами данные!",
                    "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (Attempts == 3)
            {
                Captha captha = new Captha();
                captha.ShowDialog();
            }
            if (Attempts >= 4)//если пользователь продолжает вводить неверно логин и пароль
            {//вход продолжает блокироваться на 10 секунд
                timer1.Tick += new EventHandler(timerTick2);
                timer1.Interval = new TimeSpan(0, 0, 1);
                timer1.Start();
                if (stop != 0)
                {
                    loginUser.IsEnabled = false;
                    passwordUser.IsEnabled = false;
                    MessageBox.Show(String.Format
                        ("Вход заблокирован на {0:0} секунд", stop));
                }
            }
        }
        int stop = 10;
        private void timerTick2(object sender, EventArgs e)//Блокировка входа и заполнения при последующих неверных входах
        {
            if (stop == 0)
            {
                loginUser.IsEnabled = true;
                passwordUser.IsEnabled = true;
                MessageBoxResult result = 
                    MessageBox.Show("Время вышло!\nПовторите вход заново!",
                    "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                timer1.Stop();
                stop = 10;
            }
            else
            {
                stop--;
            }

        }

        int stops = 10;
        System.Windows.Threading.DispatcherTimer timer = new System.Windows.Threading.DispatcherTimer();
        public void StartTimer()//После окончания таймера у Лаборанта
        {
            loginUser.IsEnabled = false;
            passwordUser.IsEnabled = false;
            passwordUser.IsEnabled = false;
            enter.IsEnabled = false;
            timer.Tick += new EventHandler(timerTick);
            timer.Interval = new TimeSpan(0, 0, 1);
            timer.Start();
        }
        private void timerTick(object sender, EventArgs e)//Когда время вышло
        {
            if (stops == 0)
            {
                loginUser.IsEnabled = true;
                passwordUser.IsEnabled = true;
                passwordUser.IsEnabled = true;
                enter.IsEnabled = true;
                MessageBoxResult result1 = MessageBox.Show("Время вышло!\nВойдите в систему заново!",
                    "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                timer.Stop();
                stops = 10;
            }
            else
            {
                stops--;
            }

        }

        private void CheckBox_Click(object sender, RoutedEventArgs e)
        {
            if (check.IsChecked == true)
            {
                tbUser.Text = passwordUser.Password;
                tbUser.Visibility = Visibility.Visible;
                passwordUser.Visibility = Visibility.Collapsed;
            }
            else
            {
                passwordUser.Password = tbUser.Text;
                tbUser.Visibility = Visibility.Collapsed;
                passwordUser.Visibility = Visibility.Visible;
            }
        }
    }
}
